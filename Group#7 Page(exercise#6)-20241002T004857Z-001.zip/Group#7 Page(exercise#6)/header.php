<header> 
        <nav class="navbar">
        <a href="homepage.php">Home</a>
        <a href="coffee.php">Coffee</a>
        <a href="background.php">Background</a>
        <a href="aboutUs.php">About Us</a>
        <a href="rateUs.php">Rate Us</a>
        </nav>
    </header>